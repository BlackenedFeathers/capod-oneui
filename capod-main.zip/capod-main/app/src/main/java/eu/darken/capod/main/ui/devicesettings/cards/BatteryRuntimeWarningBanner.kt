package eu.darken.capod.main.ui.devicesettings.cards

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import eu.darken.capod.R
import eu.darken.capod.common.compose.Preview2
import eu.darken.capod.common.compose.PreviewWrapper
import eu.darken.capod.monitor.core.battery.BatteryHealth

@Composable
internal fun BatteryRuntimeWarningBanner(
    slot: BatteryHealth.Slot,
    percent: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val podLabel = when (slot) {
        BatteryHealth.Slot.LEFT -> stringResource(R.string.pods_dual_left_label)
        BatteryHealth.Slot.RIGHT -> stringResource(R.string.pods_dual_right_label)
        BatteryHealth.Slot.HEADSET -> stringResource(R.string.device_settings_battery_runtime_warning_headset_label)
    }
    Surface(
        onClick = onClick,
        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.4f),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .semantics(mergeDescendants = true) {},
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Outlined.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier
                    .padding(end = 10.dp)
                    .size(20.dp),
            )
            Column(
                modifier = Modifier.weight(1f),
            ) {
                Text(
                    text = stringResource(R.string.device_settings_battery_runtime_warning_title),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
                )
                Text(
                    text = stringResource(
                        R.string.device_settings_battery_runtime_warning_description,
                        podLabel,
                        percent,
                    ),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                )
            }
        }
    }
}

@Preview2
@Composable
private fun BatteryRuntimeWarningBannerEarbudPreview() = PreviewWrapper {
    BatteryRuntimeWarningBanner(
        slot = BatteryHealth.Slot.LEFT,
        percent = 42,
        onClick = {},
    )
}

@Preview2
@Composable
private fun BatteryRuntimeWarningBannerHeadsetPreview() = PreviewWrapper {
    BatteryRuntimeWarningBanner(
        slot = BatteryHealth.Slot.HEADSET,
        percent = 50,
        onClick = {},
    )
}
