package eu.darken.capod.main.ui.overview.cards

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.twotone.BatteryChargingFull
import androidx.compose.material.icons.twotone.GridView
import androidx.compose.material.icons.twotone.Tune
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import eu.darken.capod.R
import eu.darken.capod.monitor.core.visibleAncModes
import eu.darken.capod.main.ui.overview.cards.components.AncModeSelector
import eu.darken.capod.main.ui.overview.cards.components.BatteryCapsule
import eu.darken.capod.main.ui.overview.cards.components.CompactBatterySummary
import eu.darken.capod.main.ui.overview.cards.components.batteryTierState
import eu.darken.capod.main.ui.overview.cards.components.DebugSection
import eu.darken.capod.main.ui.overview.cards.components.DeviceConnectionBadge
import eu.darken.capod.main.ui.overview.cards.components.MissingPairedDeviceBanner
import eu.darken.capod.main.ui.overview.cards.components.SignalIndicator
import eu.darken.capod.main.ui.overview.cards.components.StatusChip
import eu.darken.capod.main.ui.overview.cards.components.StatusChipRow
import eu.darken.capod.common.SystemTimeSource
import eu.darken.capod.common.compose.Preview2
import eu.darken.capod.common.compose.PreviewWrapper
import eu.darken.capod.common.compose.preview.MockPodDataProvider
import eu.darken.capod.common.theming.LocalBatteryColors
import eu.darken.capod.common.theming.fillColor
import eu.darken.capod.common.theming.textColorOrNull
import eu.darken.capod.monitor.core.PodDevice
import eu.darken.capod.monitor.core.battery.BatteryEstimate
import eu.darken.capod.monitor.core.battery.BatteryTier
import eu.darken.capod.monitor.core.battery.CaseCharges
import eu.darken.capod.monitor.core.battery.batteryTier
import eu.darken.capod.monitor.core.battery.caseCharges
import eu.darken.capod.monitor.core.batteryCaseReading
import eu.darken.capod.monitor.core.cachedBatteryFormatted
import eu.darken.capod.pods.core.apple.PodModel
import eu.darken.capod.pods.core.apple.aap.AapPodState
import eu.darken.capod.pods.core.apple.aap.protocol.AapSetting
import eu.darken.capod.pods.core.apple.ble.batteryProgress
import eu.darken.capod.pods.core.apple.ble.devices.DualApplePods
import eu.darken.capod.pods.core.apple.ble.devices.DualApplePods.LidState
import eu.darken.capod.pods.core.apple.ble.devices.HasPodStyle
import eu.darken.capod.pods.core.apple.ble.formatBatteryDurationShort
import eu.darken.capod.pods.core.apple.ble.formatBatteryPercent
import java.time.Instant

@Composable
fun DualPodsCard(
    device: PodDevice,
    isPro: Boolean = true,
    showDebug: Boolean,
    now: Instant,
    isCollapsed: Boolean = false,
    batteryEstimate: BatteryEstimate? = null,
    onToggleCollapse: (() -> Unit)? = null,
    onAncModeChange: ((AapSetting.AncMode.Value) -> Unit)? = null,
    onUpgrade: (() -> Unit)? = null,
    onDeviceSettings: (() -> Unit)? = null,
    onEditProfile: (() -> Unit)? = null,
) {
    val context = LocalContext.current

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .animateContentSize(),
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (onToggleCollapse != null) {
                            Modifier.clickable(onClick = onToggleCollapse)
                        } else {
                            Modifier
                        }
                    ),
            ) {
                Image(
                    painter = painterResource(device.iconRes),
                    contentDescription = null,
                    modifier = Modifier.size(44.dp),
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = device.label ?: "?",
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        SignalIndicator(
                            signalQuality = device.rssiQuality,
                            isLive = device.isLive,
                            modifier = Modifier.padding(start = 6.dp),
                        )
                    }
                    val deviceLabel = buildString {
                        append(device.getLabel(context))
                        val podStyle = device.ble as? HasPodStyle
                        if (podStyle != null && showDebug) {
                            append(" (${podStyle.podStyle.getColor(context)})")
                        }
                        val dualApple = device.ble as? DualApplePods
                        if (dualApple != null && showDebug) {
                            append(" [${dualApple.primaryPod.name}]")
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = deviceLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        DeviceConnectionBadge(
                            state = device.connectionState,
                            modifier = Modifier.padding(start = 6.dp),
                        )
                    }
                }

                if (device.profileId != null && onDeviceSettings != null) {
                    OutlinedIconButton(onClick = onDeviceSettings) {
                        Icon(
                            imageVector = Icons.TwoTone.Tune,
                            contentDescription = stringResource(R.string.device_settings_open_cd),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            if (!isCollapsed
                && device.profileId != null
                && !device.hasSelectedPairedDevice
                && onEditProfile != null
            ) {
                Spacer(modifier = Modifier.height(12.dp))
                MissingPairedDeviceBanner(onClick = onEditProfile)
            }

            if (isCollapsed) {
                CompactBatterySummary(device = device)
            } else {
                DualPodsCardExpanded(
                    device = device,
                    showDebug = showDebug,
                    now = now,
                    batteryEstimate = batteryEstimate,
                    onAncModeChange = onAncModeChange,
                )
            }
        }
    }
}

@Composable
private fun ColumnScope.DualPodsCardExpanded(
    device: PodDevice,
    showDebug: Boolean,
    now: Instant,
    batteryEstimate: BatteryEstimate?,
    onAncModeChange: ((AapSetting.AncMode.Value) -> Unit)?,
) {
    val context = LocalContext.current
    Spacer(modifier = Modifier.height(16.dp))

    // Circular battery gauges side by side
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (!device.isLive) Modifier.alpha(0.7f) else Modifier),
        shape = RoundedCornerShape(12.dp),
        tonalElevation = 4.dp,
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                PodGauge(
                    iconRes = device.leftPodIcon,
                    batteryPercent = device.batteryLeft,
                    chargingState = device.leftPodChargingState
                        ?: device.isLeftPodCharging?.let { if (it) AapPodState.ChargingState.CHARGING else null },
                    isInEar = device.isLeftInEar ?: false,
                    showEarDetection = device.hasEarDetection && device.hasDualPods,
                    isMicrophone = device.isLeftPodMicrophone ?: false,
                    showMicrophone = device.hasDualMicrophone,
                    modifier = Modifier.weight(1f),
                    timeRemaining = batteryEstimate?.left?.let { formatBatteryDurationShort(context, it.minutesRemaining) },
                    untilCharged = batteryEstimate?.left?.minutesUntilCharged?.let { formatBatteryDurationShort(context, it) },
                )

                PodGauge(
                    iconRes = device.rightPodIcon,
                    batteryPercent = device.batteryRight,
                    chargingState = device.rightPodChargingState
                        ?: device.isRightPodCharging?.let { if (it) AapPodState.ChargingState.CHARGING else null },
                    isInEar = device.isRightInEar ?: false,
                    showEarDetection = device.hasEarDetection && device.hasDualPods,
                    isMicrophone = device.isRightPodMicrophone ?: false,
                    showMicrophone = device.hasDualMicrophone,
                    modifier = Modifier.weight(1f),
                    timeRemaining = batteryEstimate?.right?.let { formatBatteryDurationShort(context, it.minutesRemaining) },
                    untilCharged = batteryEstimate?.right?.minutesUntilCharged?.let { formatBatteryDurationShort(context, it) },
                )
            }

            // Case row
            if (device.hasCase) {
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 8.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                )

                CaseRow(device = device)
            }
        }
    }

    // Cached battery indicator
    if (device.isBatteryCached && !device.isLive) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.battery_cached_label, device.cachedBatteryFormatted(now)),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.align(Alignment.End),
        )
    }

    // ANC mode selector
    val ancMode = device.ancMode
    if (device.isAapConnected && device.hasAncControl && ancMode != null) {
        Spacer(modifier = Modifier.height(12.dp))
        AncModeSelector(
            currentMode = ancMode.current,
            supportedModes = device.visibleAncModes,
            onModeSelected = { onAncModeChange?.invoke(it) },
            pendingMode = device.pendingAncMode,
        )
    }

    // Debug info
    if (showDebug) {
        DebugSection(rawDataHex = device.rawDataHex)
    }
}

@Composable
private fun PodGauge(
    iconRes: Int,
    batteryPercent: Float,
    chargingState: AapPodState.ChargingState?,
    isInEar: Boolean,
    showEarDetection: Boolean,
    isMicrophone: Boolean,
    showMicrophone: Boolean,
    modifier: Modifier = Modifier,
    timeRemaining: String? = null,
    untilCharged: String? = null,
) {
    val context = LocalContext.current
    val tier = batteryTier(batteryPercent)
    val isKnown = tier != BatteryTier.UNKNOWN
    val animatedProgress by animateFloatAsState(
        targetValue = batteryProgress(batteryPercent),
        animationSpec = tween(600, easing = FastOutSlowInEasing),
        label = "gaugeProgress",
    )

    val ringColor = tier.fillColor()

    Column(
        modifier = modifier.batteryTierState(tier),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Ring with icon inside
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(68.dp),
        ) {
            // Track ring
            CircularProgressIndicator(
                progress = { 1f },
                modifier = Modifier.size(68.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                strokeWidth = 6.dp,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                strokeCap = StrokeCap.Round,
            )

            // Progress ring
            if (isKnown) {
                CircularProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.size(68.dp),
                    color = ringColor,
                    strokeWidth = 6.dp,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    strokeCap = StrokeCap.Round,
                )
            }

            // Pod icon
            Image(
                painter = painterResource(iconRes),
                contentDescription = null,
                modifier = Modifier.size(36.dp),
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Battery percentage, with the time-remaining estimate inline next to it
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = formatBatteryPercent(context, batteryPercent),
                style = MaterialTheme.typography.titleMedium,
                color = tier.textColorOrNull() ?: if (isKnown) {
                    MaterialTheme.colorScheme.onSurface
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.alignByBaseline(),
            )
            if (timeRemaining != null) {
                Text(
                    text = "· $timeRemaining",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.alignByBaseline(),
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Status chips
        StatusChipRow(
            chargingState = chargingState,
            isInEar = isInEar,
            showEarDetection = showEarDetection,
            isMicrophone = isMicrophone,
            showMicrophone = showMicrophone,
            chargingLabel = stringResource(R.string.pods_charging_label),
            chargingOptimizedLabel = stringResource(R.string.pods_charging_optimized_label),
            inEarLabel = stringResource(R.string.pods_inear_label),
            microphoneLabel = stringResource(R.string.pods_microphone_label),
            chargingDetail = untilCharged,
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CaseRow(
    device: PodDevice,
) {
    val context = LocalContext.current
    val tier = batteryTier(device.batteryCase)
    val charges = caseCharges(device.model.caseSpec, device.batteryCaseReading)

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .batteryTierState(tier),
        ) {
            Image(
                painter = painterResource(device.caseIcon),
                contentDescription = null,
                modifier = Modifier.size(28.dp),
            )

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = formatBatteryPercent(context, device.batteryCase),
                style = MaterialTheme.typography.bodyMedium,
                color = tier.textColorOrNull() ?: LocalContentColor.current,
                modifier = Modifier.padding(end = 8.dp),
            )

            BatteryCapsule(
                percent = device.batteryCase,
                modifier = Modifier
                    .weight(1f)
                    .height(8.dp),
            )

            Spacer(modifier = Modifier.width(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                when (val caseState = device.caseChargingState
                    ?: device.isCaseCharging?.let { if (it) AapPodState.ChargingState.CHARGING else null }) {
                    AapPodState.ChargingState.CHARGING_OPTIMIZED -> StatusChip(
                        icon = Icons.TwoTone.BatteryChargingFull,
                        label = stringResource(R.string.pods_charging_optimized_label),
                    )
                    AapPodState.ChargingState.CHARGING -> StatusChip(
                        icon = Icons.TwoTone.BatteryChargingFull,
                        label = stringResource(R.string.pods_charging_label),
                    )
                    else -> Unit
                }

                val lidState = device.caseLidState
                if (lidState == LidState.OPEN || lidState == LidState.CLOSED) {
                    StatusChip(
                        icon = Icons.TwoTone.GridView,
                        label = when (lidState) {
                            LidState.OPEN -> stringResource(R.string.pods_case_status_open_label)
                            LidState.CLOSED -> stringResource(R.string.pods_case_status_closed_label)
                            else -> ""
                        },
                    )
                }
            }
        }

        if (charges != null) {
            CaseChargesLine(
                charges = charges,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
    }
}

/**
 * Stacked below the case row rather than inline: that row already carries four children of which
 * only the capsule is weighted, so an unbounded plural in front of it squeezes the capsule away at
 * large font scales and in locales with long plural forms.
 */
@Composable
private fun CaseChargesLine(
    charges: CaseCharges,
    modifier: Modifier = Modifier,
) {
    val text = when (charges.display) {
        CaseCharges.Display.EMPTY -> stringResource(R.string.battery_case_charges_empty)
        CaseCharges.Display.LESS_THAN_ONE -> stringResource(R.string.battery_case_charges_less_than_one)
        CaseCharges.Display.UNCERTAIN -> stringResource(R.string.battery_case_charges_uncertain)
        CaseCharges.Display.AT_LEAST -> pluralStringResource(
            R.plurals.battery_case_charges_at_least,
            charges.count,
            charges.count,
        )
        CaseCharges.Display.APPROXIMATE -> pluralStringResource(
            R.plurals.battery_case_charges_approx,
            charges.count,
            charges.count,
        )
    }
    // The same visible count can be adequate or not depending on how coarse the reading was, so
    // the adequacy needs its own announcement rather than riding on the case battery's state.
    val state = when (charges.adequacy) {
        CaseCharges.Adequacy.ENOUGH -> stringResource(R.string.battery_case_charges_state_enough_cd)
        CaseCharges.Adequacy.NOT_ENOUGH -> stringResource(R.string.battery_case_charges_state_not_enough_cd)
        CaseCharges.Adequacy.UNCERTAIN -> stringResource(R.string.battery_case_charges_state_uncertain_cd)
    }
    val color = when (charges.adequacy) {
        CaseCharges.Adequacy.ENOUGH -> LocalBatteryColors.current.positiveText
        CaseCharges.Adequacy.NOT_ENOUGH -> LocalBatteryColors.current.warnText
        CaseCharges.Adequacy.UNCERTAIN -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = color,
        textAlign = TextAlign.Center,
        modifier = modifier
            .fillMaxWidth()
            .semantics { stateDescription = state },
    )
}

@Preview2
@Composable
private fun DualPodsCardFullPreview() = PreviewWrapper {
    DualPodsCard(
        device = MockPodDataProvider.dualPodFullyLoaded(),
        showDebug = false,
        now = SystemTimeSource.now(),
        isPro = false,
        batteryEstimate = BatteryEstimate(
            left = BatteryEstimate.Pod(minutesRemaining = 135, fractionPerHour = 0.18f, source = BatteryEstimate.Source.LIVE),
            right = BatteryEstimate.Pod(minutesRemaining = 122, fractionPerHour = 0.20f, source = BatteryEstimate.Source.LIVE),
        ),
        onDeviceSettings = {},
    )
}

@Preview2
@Composable
private fun DualPodsCardEstimateLearnedPreview() = PreviewWrapper {
    // LEARNED: rate seeded from persisted history on reconnect, before this session has gathered
    // enough live samples.
    DualPodsCard(
        device = MockPodDataProvider.dualPodFullyLoaded(),
        showDebug = false,
        now = SystemTimeSource.now(),
        isPro = false,
        batteryEstimate = BatteryEstimate(
            left = BatteryEstimate.Pod(minutesRemaining = 92, fractionPerHour = 0.27f, source = BatteryEstimate.Source.LEARNED),
            right = BatteryEstimate.Pod(minutesRemaining = 100, fractionPerHour = 0.25f, source = BatteryEstimate.Source.LEARNED),
        ),
        onDeviceSettings = {},
    )
}

@Preview2
@Composable
private fun DualPodsCardEstimateProvisionalPreview() = PreviewWrapper {
    // SPEC: rated estimate shown immediately on connect, before any drain has been measured.
    DualPodsCard(
        device = MockPodDataProvider.dualPodFullyLoaded(),
        showDebug = false,
        now = SystemTimeSource.now(),
        isPro = false,
        batteryEstimate = BatteryEstimate(
            left = BatteryEstimate.Pod(minutesRemaining = 360, fractionPerHour = 0.167f, source = BatteryEstimate.Source.SPEC),
            right = BatteryEstimate.Pod(minutesRemaining = 360, fractionPerHour = 0.167f, source = BatteryEstimate.Source.SPEC),
        ),
        onDeviceSettings = {},
    )
}

@Preview2
@Composable
private fun DualPodsCardWarnPreview() = PreviewWrapper {
    // Case at 30% of a 4.0-charge spec: even the bottom of the decile band clears a full charge.
    DualPodsCard(
        device = MockPodDataProvider.dualPodBatteries(left = 0.22f, right = 0.18f, case = 0.30f),
        showDebug = false,
        now = SystemTimeSource.now(),
    )
}

@Preview2
@Composable
private fun DualPodsCardCriticalPreview() = PreviewWrapper {
    // Case at 10%: the whole band stays under a full charge.
    DualPodsCard(
        device = MockPodDataProvider.dualPodBatteries(left = 0.10f, right = 0.05f, case = 0.10f),
        showDebug = false,
        now = SystemTimeSource.now(),
    )
}

@Preview2
@Composable
private fun DualPodsCardCaseChargesUncertainPreview() = PreviewWrapper {
    // Case at 20%: the decile band straddles a full charge, so the line makes no claim.
    DualPodsCard(
        device = MockPodDataProvider.dualPodBatteries(case = 0.20f),
        showDebug = false,
        now = SystemTimeSource.now(),
    )
}

@Preview2
@Composable
private fun DualPodsCardCaseWithoutSpecPreview() = PreviewWrapper {
    // PowerBeats Pro has a case, but Apple publishes no figures for it, so there is no line.
    DualPodsCard(
        device = MockPodDataProvider.dualPodBatteries(
            case = 0.60f,
            model = PodModel.POWERBEATS_PRO,
            label = "PowerBeats Pro",
        ),
        showDebug = false,
        now = SystemTimeSource.now(),
    )
}

@Preview2
@Composable
private fun DualPodsCardMinimalPreview() = PreviewWrapper {
    DualPodsCard(
        device = MockPodDataProvider.dualPodMonitored(),
        showDebug = false,
        now = SystemTimeSource.now(),
    )
}

@Preview2
@Composable
private fun DualPodsCardCachedPreview() = PreviewWrapper {
    DualPodsCard(
        device = MockPodDataProvider.dualPodCachedOnly(),
        showDebug = false,
        now = SystemTimeSource.now(),
    )
}

@Preview2
@Composable
private fun DualPodsCardCollapsedPreview() = PreviewWrapper {
    DualPodsCard(
        device = MockPodDataProvider.dualPodMonitored(),
        showDebug = false,
        now = SystemTimeSource.now(),
        isCollapsed = true,
        onToggleCollapse = {},
    )
}

@Preview2
@Composable
private fun DualPodsCardMissingAddressPreview() = PreviewWrapper {
    DualPodsCard(
        device = MockPodDataProvider.dualPodMissingPairedDevice(),
        showDebug = false,
        now = SystemTimeSource.now(),
        onEditProfile = {},
    )
}
