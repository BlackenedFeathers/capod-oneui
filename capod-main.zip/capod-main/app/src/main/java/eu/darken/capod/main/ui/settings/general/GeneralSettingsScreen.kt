package eu.darken.capod.main.ui.settings.general

import android.os.Build
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.twotone.ArrowBack
import androidx.compose.material.icons.twotone.AccountTree
import androidx.compose.material.icons.twotone.BatteryStd
import androidx.compose.material.icons.twotone.Contrast
import androidx.compose.material.icons.twotone.DarkMode
import androidx.compose.material.icons.twotone.FilterList
import androidx.compose.material.icons.automirrored.twotone.Message
import androidx.compose.material.icons.twotone.Notifications
import androidx.compose.material.icons.twotone.Palette
import androidx.compose.material.icons.twotone.VisibilityOff
import androidx.compose.material.icons.automirrored.twotone.ViewList
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import eu.darken.capod.R
import eu.darken.capod.common.compose.Preview2
import eu.darken.capod.common.compose.PreviewWrapper
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import eu.darken.capod.common.error.ErrorEventHandler
import eu.darken.capod.common.navigation.NavigationEventHandler
import eu.darken.capod.common.settings.SettingsBaseItem
import eu.darken.capod.common.settings.SettingsCategoryHeader
import eu.darken.capod.common.settings.SettingsListPreferenceItem
import eu.darken.capod.common.settings.ThemeColorSelectorDialog
import eu.darken.capod.common.theming.ThemeColor
import eu.darken.capod.common.theming.ThemeMode
import eu.darken.capod.common.theming.ThemeState
import eu.darken.capod.common.theming.ThemeStyle

@Composable
fun GeneralSettingsScreenHost(vm: GeneralSettingsViewModel = hiltViewModel()) {
    ErrorEventHandler(vm)
    NavigationEventHandler(vm)

    val state by vm.state.collectAsStateWithLifecycle(initialValue = null)
    state?.let {
        GeneralSettingsScreen(
            state = it,
            onNavigateUp = { vm.navUp() },
            onShowConnectedNotificationChanged = { enabled -> vm.setShowConnectedNotification(enabled) },
            onKeepNotificationAfterDisconnectChanged = { enabled -> vm.setKeepNotificationAfterDisconnect(enabled) },
            onShowBatteryInStatusBarChanged = { enabled -> vm.setShowBatteryInStatusBar(enabled) },
            onOffloadedFilteringDisabledChanged = { disabled -> vm.setOffloadedFilteringDisabled(disabled) },
            onOffloadedBatchingDisabledChanged = { disabled -> vm.setOffloadedBatchingDisabled(disabled) },
            onUseIndirectScanResultCallbackChanged = { enabled -> vm.setUseIndirectScanResultCallback(enabled) },
            onHideUnmatchedDevicesChanged = { enabled -> vm.setHideUnmatchedDevices(enabled) },
            onThemeModeSelected = { mode -> vm.setThemeMode(mode) },
            onThemeStyleSelected = { style -> vm.setThemeStyle(style) },
            onThemeColorSelected = { color -> vm.setThemeColor(color) },
            onUpgrade = { vm.launchUpgrade() },
        )
    }
}

@Composable
fun GeneralSettingsScreen(
    state: GeneralSettingsViewModel.State,
    onNavigateUp: () -> Unit,
    onShowConnectedNotificationChanged: (Boolean) -> Unit,
    onKeepNotificationAfterDisconnectChanged: (Boolean) -> Unit,
    onOffloadedFilteringDisabledChanged: (Boolean) -> Unit,
    onOffloadedBatchingDisabledChanged: (Boolean) -> Unit,
    onUseIndirectScanResultCallbackChanged: (Boolean) -> Unit,
    onHideUnmatchedDevicesChanged: (Boolean) -> Unit,
    onShowBatteryInStatusBarChanged: (Boolean) -> Unit = {},
    onThemeModeSelected: (ThemeMode) -> Unit = {},
    onThemeStyleSelected: (ThemeStyle) -> Unit = {},
    onThemeColorSelected: (ThemeColor) -> Unit = {},
    onUpgrade: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    var showColorDialog by remember { mutableStateOf(false) }

    val isMaterialYouActive = state.themeState.style == ThemeStyle.MATERIAL_YOU &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(text = stringResource(R.string.settings_general_label)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateUp) {
                        Icon(
                            imageVector = Icons.AutoMirrored.TwoTone.ArrowBack,
                            contentDescription = null,
                        )
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = innerPadding,
        ) {
            item {
                SettingsCategoryHeader(text = stringResource(R.string.settings_category_appearance_label))
            }
            item {
                if (!state.isUpgradeLocked) {
                    SettingsListPreferenceItem(
                        icon = Icons.TwoTone.DarkMode,
                        title = stringResource(R.string.ui_theme_mode_label),
                        entries = ThemeMode.entries,
                        selectedEntry = state.themeState.mode,
                        onEntrySelected = onThemeModeSelected,
                        entryLabel = { stringResource(it.labelRes) },
                    )
                } else {
                    SettingsBaseItem(
                        icon = Icons.TwoTone.DarkMode,
                        title = stringResource(R.string.ui_theme_mode_label),
                        subtitle = stringResource(state.themeState.mode.labelRes),
                        onClick = onUpgrade,
                        requiresUpgrade = true,
                    )
                }
            }
            item {
                if (!state.isUpgradeLocked) {
                    SettingsListPreferenceItem(
                        icon = Icons.TwoTone.Contrast,
                        title = stringResource(R.string.ui_theme_style_label),
                        entries = ThemeStyle.entries,
                        selectedEntry = state.themeState.style,
                        onEntrySelected = onThemeStyleSelected,
                        entryLabel = { stringResource(it.labelRes) },
                    )
                } else {
                    SettingsBaseItem(
                        icon = Icons.TwoTone.Contrast,
                        title = stringResource(R.string.ui_theme_style_label),
                        subtitle = stringResource(state.themeState.style.labelRes),
                        onClick = onUpgrade,
                        requiresUpgrade = true,
                    )
                }
            }
            item {
                SettingsBaseItem(
                    title = stringResource(R.string.ui_theme_color_label),
                    subtitle = if (isMaterialYouActive) {
                        stringResource(R.string.ui_theme_color_disabled_materialyou)
                    } else {
                        stringResource(state.themeState.color.labelRes)
                    },
                    icon = Icons.TwoTone.Palette,
                    onClick = {
                        if (state.isUpgradeLocked) onUpgrade() else showColorDialog = true
                    },
                    enabled = !isMaterialYouActive,
                    requiresUpgrade = state.isUpgradeLocked && !isMaterialYouActive,
                )
            }
            item {
                SettingsCategoryHeader(text = stringResource(R.string.settings_category_other_label))
            }
            item {
                SettingsBaseItem(
                    title = stringResource(R.string.settings_monitor_connected_notification_label),
                    subtitle = stringResource(R.string.settings_monitor_connected_notification_description),
                    icon = Icons.TwoTone.Notifications,
                    onClick = { onShowConnectedNotificationChanged(!state.showConnectedNotification) },
                    trailingContent = {
                        Switch(
                            checked = state.showConnectedNotification,
                            onCheckedChange = onShowConnectedNotificationChanged,
                            modifier = Modifier.padding(start = 16.dp),
                        )
                    },
                )
            }
            item {
                SettingsBaseItem(
                    title = stringResource(R.string.settings_keep_notification_after_disconnect_label),
                    subtitle = stringResource(R.string.settings_keep_notification_after_disconnect_description),
                    icon = Icons.AutoMirrored.TwoTone.Message,
                    onClick = { onKeepNotificationAfterDisconnectChanged(!state.keepNotificationAfterDisconnect) },
                    enabled = state.showConnectedNotification,
                    trailingContent = {
                        Switch(
                            checked = state.keepNotificationAfterDisconnect,
                            onCheckedChange = onKeepNotificationAfterDisconnectChanged,
                            enabled = state.showConnectedNotification,
                            modifier = Modifier.padding(start = 16.dp),
                        )
                    },
                )
            }
            item {
                SettingsBaseItem(
                    title = stringResource(R.string.settings_monitor_statusbar_battery_label),
                    subtitle = stringResource(R.string.settings_monitor_statusbar_battery_description),
                    icon = Icons.TwoTone.BatteryStd,
                    onClick = { onShowBatteryInStatusBarChanged(!state.showBatteryInStatusBar) },
                    trailingContent = {
                        Switch(
                            checked = state.showBatteryInStatusBar,
                            onCheckedChange = onShowBatteryInStatusBarChanged,
                            modifier = Modifier.padding(start = 16.dp),
                        )
                    },
                )
            }
            item {
                SettingsBaseItem(
                    title = stringResource(R.string.settings_overview_hide_unmatched_label),
                    subtitle = stringResource(R.string.settings_overview_hide_unmatched_description),
                    icon = Icons.TwoTone.VisibilityOff,
                    onClick = { onHideUnmatchedDevicesChanged(!state.hideUnmatchedDevices) },
                    trailingContent = {
                        Switch(
                            checked = state.hideUnmatchedDevices,
                            onCheckedChange = onHideUnmatchedDevicesChanged,
                            modifier = Modifier.padding(start = 16.dp),
                        )
                    },
                )
            }
            item {
                SettingsCategoryHeader(
                    text = stringResource(R.string.settings_category_compatibility_options_title),
                    subtitle = stringResource(R.string.settings_category_compatibility_options_description),
                )
            }
            item {
                SettingsBaseItem(
                    title = stringResource(R.string.settings_compat_offloaded_filtering_disabled_title),
                    subtitle = stringResource(R.string.settings_compat_offloaded_filtering_disabled_summary),
                    icon = Icons.TwoTone.FilterList,
                    onClick = { onOffloadedFilteringDisabledChanged(!state.isOffloadedFilteringDisabled) },
                    trailingContent = {
                        Switch(
                            checked = state.isOffloadedFilteringDisabled,
                            onCheckedChange = onOffloadedFilteringDisabledChanged,
                            modifier = Modifier.padding(start = 16.dp),
                        )
                    },
                )
            }
            item {
                SettingsBaseItem(
                    title = stringResource(R.string.settings_compat_offloaded_batching_disabled_title),
                    subtitle = stringResource(R.string.settings_compat_offloaded_batching_disabled_summary),
                    icon = Icons.AutoMirrored.TwoTone.ViewList,
                    onClick = { onOffloadedBatchingDisabledChanged(!state.isOffloadedBatchingDisabled) },
                    trailingContent = {
                        Switch(
                            checked = state.isOffloadedBatchingDisabled,
                            onCheckedChange = onOffloadedBatchingDisabledChanged,
                            modifier = Modifier.padding(start = 16.dp),
                        )
                    },
                )
            }
            item {
                SettingsBaseItem(
                    title = stringResource(R.string.settings_compat_indirectcallback_title),
                    subtitle = stringResource(R.string.settings_compat_indirectcallback_summary),
                    icon = Icons.TwoTone.AccountTree,
                    onClick = { onUseIndirectScanResultCallbackChanged(!state.useIndirectScanResultCallback) },
                    trailingContent = {
                        Switch(
                            checked = state.useIndirectScanResultCallback,
                            onCheckedChange = onUseIndirectScanResultCallbackChanged,
                            modifier = Modifier.padding(start = 16.dp),
                        )
                    },
                )
            }
        }
    }

    if (showColorDialog) {
        ThemeColorSelectorDialog(
            selectedColor = state.themeState.color,
            onColorSelected = {
                onThemeColorSelected(it)
                showColorDialog = false
            },
            onDismiss = { showColorDialog = false },
        )
    }
}

private fun previewGeneralState(isPro: Boolean) = GeneralSettingsViewModel.State(
    isUpgradeLocked = !isPro,
    showConnectedNotification = true,
    keepNotificationAfterDisconnect = false,
    showBatteryInStatusBar = false,
    isOffloadedFilteringDisabled = false,
    isOffloadedBatchingDisabled = false,
    useIndirectScanResultCallback = false,
    hideUnmatchedDevices = false,
    themeState = ThemeState(),
)

@Preview2
@Composable
private fun GeneralSettingsScreenProPreview() = PreviewWrapper {
    GeneralSettingsScreen(
        state = previewGeneralState(isPro = true),
        onNavigateUp = {},
        onShowConnectedNotificationChanged = {},
        onKeepNotificationAfterDisconnectChanged = {},
        onOffloadedFilteringDisabledChanged = {},
        onOffloadedBatchingDisabledChanged = {},
        onUseIndirectScanResultCallbackChanged = {},
        onHideUnmatchedDevicesChanged = {},
    )
}

@Preview2
@Composable
private fun GeneralSettingsScreenNonProPreview() = PreviewWrapper {
    GeneralSettingsScreen(
        state = previewGeneralState(isPro = false),
        onNavigateUp = {},
        onShowConnectedNotificationChanged = {},
        onKeepNotificationAfterDisconnectChanged = {},
        onOffloadedFilteringDisabledChanged = {},
        onOffloadedBatchingDisabledChanged = {},
        onUseIndirectScanResultCallbackChanged = {},
        onHideUnmatchedDevicesChanged = {},
    )
}
