package eu.darken.capod.main.ui.widget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.core.view.WindowCompat
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.lifecycle.lifecycleScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import eu.darken.capod.common.debug.logging.log
import eu.darken.capod.common.debug.logging.logTag
import eu.darken.capod.common.theming.CapodTheme
import eu.darken.capod.common.uix.Activity2
import eu.darken.capod.common.upgrade.UpgradeRepo
import eu.darken.capod.main.ui.MainActivity
import eu.darken.capod.main.core.GeneralSettings
import eu.darken.capod.main.core.currentThemeState
import eu.darken.capod.main.core.themeState
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class WidgetConfigurationActivity : Activity2() {

    private val vm: WidgetConfigurationViewModel by viewModels()

    @Inject lateinit var generalSettings: GeneralSettings
    @Inject lateinit var upgradeRepo: UpgradeRepo
    @ApplicationContext @Inject lateinit var appContext: Context

    private var widgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID

    private val upgradeLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != RESULT_OK) {
            log(TAG) { "Upgrade flow canceled or incomplete (resultCode=${result.resultCode})" }
            return@registerForActivityResult
        }
        // Same gate as the confirm tap: the return path re-asks the ViewModel instead of trusting
        // the upgrade activity's result code, so RESULT_OK is only ever set for an entitled, valid
        // configuration.
        lifecycleScope.launch {
            when (vm.decideConfirm()) {
                WidgetConfigurationViewModel.ConfirmOutcome.Confirmed -> {
                    log(TAG) { "Upgrade completed, auto-confirming widget selection" }
                    confirmSelection(vm.state.first().isAncWidget)
                }

                WidgetConfigurationViewModel.ConfirmOutcome.UpgradeRequired,
                WidgetConfigurationViewModel.ConfirmOutcome.Invalid -> {
                    log(TAG) { "Upgrade returned, but confirming is not possible, staying in config" }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setResult(RESULT_CANCELED)

        widgetId = intent.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        )

        log(TAG) { "onCreate(widgetId=$widgetId)" }

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            log(TAG) { "Invalid widget ID, finishing" }
            finish()
            return
        }

        setContent {
            val themeState by generalSettings.themeState.collectAsStateWithLifecycle(initialValue = generalSettings.currentThemeState)
            CapodTheme(state = themeState) {
                val backgroundColor = MaterialTheme.colorScheme.background
                val useDarkIcons = backgroundColor.luminance() > 0.5f
                SideEffect {
                    window.decorView.setBackgroundColor(backgroundColor.toArgb())
                    val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                    insetsController.isAppearanceLightStatusBars = useDarkIcons
                    insetsController.isAppearanceLightNavigationBars = useDarkIcons
                }

                val state by vm.state.collectAsStateWithLifecycle(initialValue = null)
                state?.let { currentState ->
                    WidgetConfigurationScreen(
                        state = currentState,
                        showAapRequiredHint = currentState.isAncWidget,
                        onSelectProfile = { profile -> vm.selectProfile(profile.id) },
                        onSelectPreset = { preset -> vm.selectPreset(preset) },
                        onEnterCustomMode = { bg, fg -> vm.enterCustomMode(bg, fg) },
                        onSetBackgroundColor = { color -> vm.setBackgroundColor(color) },
                        onSetForegroundColor = { color -> vm.setForegroundColor(color) },
                        onSetBackgroundAlpha = { alpha -> vm.setBackgroundAlpha(alpha) },
                        onSetShowDeviceLabel = { show -> vm.setShowDeviceLabel(show) },
                        onReset = { vm.resetToDefaults() },
                        onConfirm = {
                            // The decision is made in the ViewModel (suspending entitlement gate),
                            // so RESULT_OK is only ever set for an entitled, valid configuration.
                            lifecycleScope.launch {
                                when (vm.decideConfirm()) {
                                    WidgetConfigurationViewModel.ConfirmOutcome.Confirmed -> {
                                        confirmSelection(currentState.isAncWidget)
                                    }

                                    WidgetConfigurationViewModel.ConfirmOutcome.UpgradeRequired -> {
                                        upgradeLauncher.launch(
                                            Intent(
                                                this@WidgetConfigurationActivity,
                                                MainActivity::class.java
                                            ).apply {
                                                putExtra(MainActivity.EXTRA_NAVIGATE_TO_UPGRADE, true)
                                                putExtra(MainActivity.EXTRA_UPGRADE_FOR_RESULT, true)
                                            }
                                        )
                                    }

                                    WidgetConfigurationViewModel.ConfirmOutcome.Invalid -> {
                                        log(TAG) { "Confirm rejected, staying in config" }
                                    }
                                }
                            }
                        },
                        onCancel = { finish() },
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Per-resume, unthrottled entitlement reconciliation. This activity is a second launcher
        // entry point (the widget picker starts it directly), so it can't rely on MainActivity
        // having reconciled: it needs its own. refresh() is bounded and swallows its own failures.
        lifecycleScope.launch {
            log(TAG) { "onResume(): refreshing upgrade info" }
            upgradeRepo.refresh()
        }
    }

    private fun confirmSelection(isAncWidget: Boolean) {
        vm.confirmSelection()

        val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
        setResult(RESULT_OK, resultValue)

        lifecycleScope.launch {
            val manager = GlanceAppWidgetManager(appContext)
            val glanceId = manager.getGlanceIdBy(widgetId)
            if (isAncWidget) {
                AncGlanceWidget().update(appContext, glanceId)
            } else {
                BatteryGlanceWidget().update(appContext, glanceId)
            }
            finish()
        }
    }

    companion object {
        private val TAG = logTag("Widget", "ConfigurationActivity")
    }
}
